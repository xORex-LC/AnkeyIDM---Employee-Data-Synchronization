from __future__ import annotations

import logging
from typing import Any, Protocol

from ..models import CsvRow, EmployeeInput, RowRef, ValidationErrorItem, ValidationRowResult
from .deps import DatasetValidationState, ValidationDependencies
from .row_rules import FIELD_RULES, RowRule, normalize_whitespace
from .dataset_rules import MatchKeyUniqueRule, OrgExistsRule, UsrOrgTabUniqueRule

class DatasetRule(Protocol):
    """
    Назначение:
        Контракт для глобальных правил валидации набора строк.
    """

    def apply(
        self,
        employee: EmployeeInput,
        result: ValidationRowResult,
        state: DatasetValidationState,
        deps: ValidationDependencies,
    ) -> None: ...

class RowValidator:
    """
    Назначение/ответственность:
        Выполняет валидацию одной строки CSV на уровне полей (парсинг/формат).

    Взаимодействия:
        - Использует набор RowRule.
        - Не выполняет глобальные проверки (уникальности, наличие org).
    """

    def __init__(self, rules: tuple[RowRule, ...]) -> None:
        self.rules = rules

    def _collect_fields(
        self, csvRow: CsvRow
    ) -> tuple[dict[str, Any], list[ValidationErrorItem], list[ValidationErrorItem]]:
        errors: list[ValidationErrorItem] = []
        warnings: list[ValidationErrorItem] = []
        values: dict[str, Any] = {}
        for rule in self.rules:
            values[rule.name] = rule.apply(csvRow.values, errors, warnings)
        return values, errors, warnings

    def validate(self, csv_row: CsvRow) -> tuple[EmployeeInput, ValidationRowResult]:
        """
        Контракт:
            csv_row: нормализованная строка CSV.
            Возвращает EmployeeInput + ValidationRowResult с ошибками/варнингами полей.
        """
        values, errors, warnings = self._collect_fields(csv_row)

        employee = EmployeeInput(
            email=values.get("email"),
            last_name=values.get("lastName"),
            first_name=values.get("firstName"),
            middle_name=values.get("middleName"),
            is_logon_disable=values.get("isLogonDisable"),
            user_name=values.get("userName"),
            phone=values.get("phone"),
            password=values.get("password"),
            personnel_number=values.get("personnelNumber"),
            manager_id=values.get("managerId"),
            organization_id=values.get("organization_id"),
            position=values.get("position"),
            avatar_id=values.get("avatarId"),
            usr_org_tab_num=values.get("usrOrgTabNum"),
        )

        match_key = build_match_key(employee)
        match_key_complete = all(
            [employee.last_name, employee.first_name, employee.middle_name, employee.personnel_number]
        )

        row_ref = RowRef(
            line_no=csv_row.file_line_no,
            row_id=f"line:{csv_row.file_line_no}",
            identity_primary="match_key",
            identity_value=match_key,
        )

        result = ValidationRowResult(
            line_no=csv_row.file_line_no,
            match_key=match_key,
            match_key_complete=match_key_complete,
            usr_org_tab_num=employee.usr_org_tab_num,
            row_ref=row_ref,
            errors=errors,
            warnings=warnings,
        )
        return employee, result

class DatasetValidator:
    """
    Назначение/ответственность:
        Применяет глобальные правила к результатам строковой валидации, используя
        общее состояние (уникальности, наличие связанных сущностей).
    """

    def __init__(
        self,
        rules: tuple[DatasetRule, ...],
        state: DatasetValidationState,
        deps: ValidationDependencies,
    ) -> None:
        self.rules = rules
        self.state = state
        self.deps = deps

    def validate(self, employee: EmployeeInput, result: ValidationRowResult) -> None:
        """
        Контракт:
            - Модифицирует result.errors/result.warnings, обновляет state.
        """
        for rule in self.rules:
            rule.apply(employee, result, self.state, self.deps)

def build_match_key(employee: EmployeeInput) -> str:
    parts = [
        normalize_whitespace(employee.last_name) or "",
        normalize_whitespace(employee.first_name) or "",
        normalize_whitespace(employee.middle_name) or "",
        normalize_whitespace(employee.personnel_number) or "",
    ]
    return "|".join(parts)

class ValidatorFactory:
    """
    Назначение/ответственность:
        Собирает валидаторы и контекст валидации, подставляя зависимости.
    """

    def __init__(self, deps: ValidationDependencies) -> None:
        self.deps = deps

    def create_validation_context(self) -> DatasetValidationState:
        """
        Возвращает:
            DatasetValidationState — состояние глобальных проверок.
        """
        return DatasetValidationState(matchkey_seen={}, usr_org_tab_seen={})

    def create_row_validator(self) -> RowValidator:
        """
        Возвращает:
            RowValidator с базовыми FIELD_RULES.
        """
        return RowValidator(FIELD_RULES)

    def create_dataset_validator(self, state: DatasetValidationState) -> DatasetValidator:
        """
        Возвращает:
            DatasetValidator с набором глобальных правил.
        """
        dataset_rules: tuple[DatasetRule, ...] = (
            MatchKeyUniqueRule(),
            UsrOrgTabUniqueRule(),
            OrgExistsRule(),
        )
        return DatasetValidator(
            rules=dataset_rules,
            state=state,
            deps=self.deps,
        )

# Совместимость: логирование валидации
def logValidationFailure(
    logger,
    run_id: str,
    context: str,
    result: ValidationRowResult,
    report_item_index: int | None,
    errors: list[ValidationErrorItem] | None = None,
    warnings: list[ValidationErrorItem] | None = None,
) -> None:
    """
    Назначение:
        Логирует информацию о невалидной строке CSV.
    """
    eff_errors = errors if errors is not None else result.errors
    eff_warnings = warnings if warnings is not None else result.warnings

    codes: list[str] = []
    codes.extend(e.code for e in eff_errors)
    codes.extend(w.code for w in eff_warnings)
    code_str = ",".join(sorted(set(codes))) if codes else "none"
    index_str = (
        str(report_item_index)
        if report_item_index is not None
        else f"line:{result.line_no} (not stored: limit reached)"
    )
    logger.log(
        logging.WARNING,
        f"invalid row line={result.line_no} report_item_index={index_str} errors={code_str}",
        extra={"runId": run_id, "component": context},
    )
