"""
Cache layer abstractions and helpers (SQLite store and mappers).
"""
